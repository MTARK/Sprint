import Message from "./messages.js";
let groupName = "";
let onlineUsers = 0;
let loginUserObj = {
  id: "",
  name: "",
};

let loginUserArray = [];

document.addEventListener("onload", init());

function init() {
  document.querySelector("#joinGroup").addEventListener("click", joinGroup);
  document.querySelector("#sendMessage").addEventListener("click", sendMassage);
  document
    .querySelector("#MessageContent")
    .addEventListener("keypress", function (e) {
      if (e.key === "Enter") {
        sendMassage();
      }
    });
  document
    .querySelector("#groupField")
    .addEventListener("keypress", function (e) {
      if (e.key === "Enter") {
        joinGroup();
      }
    });
  document.querySelector("#logOutfield").addEventListener("click", logOutfun);
}

//Log out
function logOutfun() {
  loginUserObj.name= "LogOut";
  pushMessageToPusher(loginUserObj);
  loginUserObj = null;
  groupName = "";
  document.querySelector("#loginUserField").value = "";
  document.querySelector("#groupField").value = "";
  document.querySelector("#window2").style.display = "none";
  document.querySelector("#window1").style.display = "block";
  loginUserArray=[];
  document.querySelector("#myPane").innerHTML="";
  // to reload all compenent form scratch after loging out
  let windowLoadAfter = 1 * 1000;
  setTimeout(function() {
    location.reload();
}, windowLoadAfter);
}

//Join Group
function joinGroup() {
  let name = document.querySelector("#loginUserField").value;
  groupName = document.querySelector("#groupField").value;
  if (name != "" && groupName != "") {
    document.querySelector("#window1").style.display = "none";
    document.querySelector("#window2").style.display = "block";
    // create me
    loginUserObj.id = getGUID();
    loginUserObj.name = name;
    subscribeToPusher();
    // put me in the array
    //push login message to pusher
    loginUserArray.push(loginUserObj);
    pushMessageToPusher(loginUserObj);
  }
  document.querySelector("#GroupIDfield").textContent = groupName;
  document.querySelector("#onlineUserField").textContent = "(Pending..)";
}

//Send Message
function sendMassage() {
  let msgContent = document.querySelector("#MessageContent").value;
  if (msgContent=="") return;
  let mymessage = new Message(
    loginUserObj.id,
    loginUserObj.name,
    msgContent,
    ""
  );
  mymessage.setDefaultTime();
  pushMessageToPusher(mymessage);
  document.querySelector("#MessageContent").value = "";
}

//Message body
function createMessageobject(msg, flout) {
  let myPane = document.querySelector("#myPane");
  let messageObject = ` <div class="toast solid-bg" role="alert" aria-live="assertive" aria-atomic="true" style="display: block; float:${flout} ; width: 660px;"">
                            <div class="toast-header " >
                            <strong class="me-auto">${msg.sender.name} </strong>
                            <small>${msg.time}</small>
                            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                           <p>${msg.content} </P>
                        </div>
                        </div>
                        </div>`;

  myPane.insertAdjacentHTML("beforeEnd", messageObject);
}

//Send message to pusher
async function pushMessageToPusher(message) {
  const MY_CHANNEL = "chat_app";
  const API_ID = "1261457";
  const API_KEY = "b9fc083715e91c3dc121";
  const CLUSTER = "eu";
  const secret = "e8525e667963b8b40035";
  let body = {
    data: JSON.stringify(message),
    name: groupName,
    channel: MY_CHANNEL,
    info: "subscription_count",
  };
  let timeStamp = Math.floor(new Date().getTime() / 1000).toString();
  let md5 = getMD5(body);
  let url = `https://cors.bridged.cc/https://api-${CLUSTER}.pusher.com/apps/${API_ID}/events?body_md5=${md5}&auth_version=1.0&auth_key=${API_KEY}&auth_timestamp=${timeStamp}&auth_signature=${getAuthSignature(
    md5,
    timeStamp,
    API_ID,
    API_KEY,
    secret
  )}`;
  let req = await fetch(url, {
    method: "POST",
    body: JSON.stringify(body),
    headers: {
      "Content-Type": "application/json",
    },
  });
}

function getMD5(body) {
  return CryptoJS.MD5(JSON.stringify(body));
}

//Auth
function getAuthSignature(md5, timeStamp, appID, key, secret) {
  return CryptoJS.HmacSHA256(
    `POST\n/apps/${appID}/events\nauth_key=${key}&auth_timestamp=${timeStamp}&auth_version=1.0&body_md5=${md5}`,
    secret
  );
}

//Listen on pusher
function getMessgesFromPusher(data) {
  let msg = data;
  let float = "";
  if (ismymessage(msg)) {
    float = "Right";
    msg.sender.name = "You";
  } else {
    float = "Left";
  }
  createMessageobject(msg, float);
  return data;
}

//My message
function ismymessage(msg) {
  return msg.sender.id == loginUserObj.id;
}

//Subscribtion to pusher
function subscribeToPusher() {
  const MY_CHANNEL = "chat_app";
  const API_ID = "1261457";
  const API_KEY = "b9fc083715e91c3dc121";
  const CLUSTER = "eu";

  var pusher = new Pusher(API_KEY, {
    cluster: CLUSTER,
  });

  var channel = pusher.subscribe(MY_CHANNEL);
  channel.bind(groupName, function (data) {
    // if login message

    if (isLoginMessage(data)) {
      upateLoginUser(data);
    } else {
      getMessgesFromPusher(data);
    }
  });
}

//updating active users
function upateLoginUser(recivedData) {
  if(recivedData.name=="LogOut"){
    let logoutuser =-1;
    loginUserArray.forEach((e) => {
      if (recivedData.id == e.id) {
         logoutuser = loginUserArray.indexOf(e);
      }
    });
    loginUserArray.splice (logoutuser ,1);
  }else if (!loginUserArray.some((e) => e.id === recivedData.id)) {
    let newuser = recivedData;
    loginUserArray.push(newuser);
    pushMessageToPusher(loginUserObj);
  }
  document.querySelector("#onlineUserField").textContent =
    "(" + loginUserArray.length + ")";
  let onlineUsersList = "";
  document.querySelector("#onlineUser").innerHTML = "";
  loginUserArray.forEach((e) => {
    let me= (( e.id == loginUserObj.id ) ? "<strong>(You)</strong>":"") ; 
    debugger;
    onlineUsersList =
      onlineUsersList + `<a href="#" class="list-group-item">${e.name} ${me}</a>`;
  });
  document
    .querySelector("#onlineUser")
    .insertAdjacentHTML("beforeEnd", onlineUsersList);
}

//Check if login
function isLoginMessage(data) {
  return true && data.id;
}

function getGUID() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
    var r = (Math.random() * 16) | 0,
      v = c == "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}